.. cblearn documentation master file, created by
   sphinx-quickstart on Thu Sep 24 11:10:46 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cblearn's documentation!
===================================

.. warning::
    cblearn is work in progress. The API can change and bugs appear. Please help us by posting an issue on Github.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install
   user_guide/index
   generated_examples/index.rst
   references/index
   contributor_guide/index





Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
